/*                                                                                                                      */let active = false; // Biến kiểm soát trạng thái extension
let activityTimeout; // Lưu setTimeout để có thể clear

function stopAllFunctions() {
    console.log("❌ Stopping all functions.");
    active = false;

    // Xóa các sự kiện hoặc quá trình đang chạy
    clearTimeout(activityTimeout);
    document.removeEventListener("visibilitychange", overrideVisibilityAPI, true);
    window.removeEventListener("blur", overrideVisibilityAPI, true);
}

chrome.storage.local.get("enabled", (data) => {
    if (!data.enabled) {
        console.log("❌ Extension is disabled.");
        return;
    }

    console.log("✅ Extension is enabled!");
    active = true; // Kích hoạt các tính năng

    function simulateUserActivity() {
        if (!active) return; // Ngừng nếu extension bị tắt
        let eventTypes = ["mousemove", "keydown", "scroll", "click"];
        let eventType = eventTypes[Math.floor(Math.random() * eventTypes.length)];
        document.dispatchEvent(new Event(eventType));
        let nextInterval = Math.floor(Math.random() * 15000) + 10000; // 10s - 25s
        activityTimeout = setTimeout(simulateUserActivity, nextInterval);
    }

    function keepTabActive() {
        if (!active) return;
        Object.defineProperty(document, "hidden", { value: false, configurable: true });
        Object.defineProperty(document, "visibilityState", { value: "visible", configurable: true });
        window.dispatchEvent(new Event("focus"));
    }

    function overrideVisibilityAPI() {
        if (!active) return;
        document.addEventListener("visibilitychange", (event) => {
            event.stopImmediatePropagation();
        }, true);

        window.addEventListener("blur", (event) => {
            event.stopImmediatePropagation();
            window.dispatchEvent(new Event("focus"));
        }, true);
    }

    function preventVideoPause() {
        if (!active) return;
        let video = document.querySelector("video");
        if (video) {
            video.play();
            video.addEventListener("pause", () => {
                if (active) video.play();
            });
        }
    }

    function autoCompleteAndNext() {
        if (!active) return;
        setTimeout(() => {
            console.log("⏳ Checking for 'Mark as Complete' button...");
            waitForElement("button[data-testid='mark-complete']", (btn) => {
                clickButton("button[data-testid='mark-complete']");
                
                console.log("⏳ Checking for 'Go to Next Item' button...");
                waitForElement("button[data-testid='next-item']", (nextBtn) => {
                    setTimeout(() => {
                        clickButton("button[data-testid='next-item']");
                    }, 2000);
                });
            });
        }, 30000);
    }

    overrideVisibilityAPI();
    keepTabActive();
    simulateUserActivity();
    preventVideoPause();
    autoCompleteAndNext();
});

// ** Lắng nghe sự thay đổi trạng thái để tắt extension ngay lập tức **
chrome.storage.onChanged.addListener((changes) => {
    if (changes.enabled) {
        if (changes.enabled.newValue === false) {
            stopAllFunctions();
        } else {
            console.log("✅ Extension re-enabled!");
            active = true;
            keepTabActive();
            simulateUserActivity();
            preventVideoPause();
            autoCompleteAndNext();
        }
    }
});
